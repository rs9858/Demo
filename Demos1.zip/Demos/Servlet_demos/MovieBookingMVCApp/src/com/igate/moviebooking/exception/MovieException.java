package com.igate.moviebooking.exception;

/*
 * User exception class to define custom exceptions wrapped around pre-defined exceptions like SQLException, Naming Exception
 */
public class MovieException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MovieException(String message) {
		super(message);
	}
}
